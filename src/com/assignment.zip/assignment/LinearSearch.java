package com.assignment;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("array size :");
		int size = sc.nextInt();
		int flag = 0;
		int numbers[] = new int[size];
		System.out.print("Enter the elements : ");

		for (int i = 0; i < size; i++) {
			numbers[i] = sc.nextInt();
		}

		System.out.println("Enter the key to search : ");
		int key = sc.nextInt();
		sc.close();
		for (int i = 0; i < size; i++) {

			if (numbers[i] == key) {
				flag = 1;
				break;
			}
		}
		if (flag == 1) {
			System.out.println("Item found !");
		} else {
			System.out.println("Item " + key + " Not found !");
		}

	}

}
